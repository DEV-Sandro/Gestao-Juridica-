import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  standalone: false // <--- OBRIGATÓRIO
})
export class DashboardComponent { }