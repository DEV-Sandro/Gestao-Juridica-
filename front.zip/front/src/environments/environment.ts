export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyChOpALFQBQeqcpAAGqSC0Inp8ywluHJks",
    authDomain: "advocacia-sistema-80239.firebaseapp.com",
    projectId: "advocacia-sistema-80239",
    storageBucket: "advocacia-sistema-80239.firebasestorage.app",
    messagingSenderId: "932904505083",
    appId: "1:932904505083:web:4ca51972fd4db43389aa5e"
  }
};